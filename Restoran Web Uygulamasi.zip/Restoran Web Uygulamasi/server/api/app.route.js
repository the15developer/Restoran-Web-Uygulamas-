const express = require('express');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');



const router = express.Router();

    
const Reservation = require('../models/reservations');
const User = require('../models/user');
const chefReview = require('../models/chef-review')


router.get('/', (req, res) => {
    //res.send('Hello, World! I am currently making a web app !');
    res.sendFile(path.join(__dirname, '..', '..', 'public', 'anasayfa.html'));
  });


router.get('/about', (req, res) => {
    //res.send('Hello, World! I am currently making a web app !');
   res.sendFile(path.join(__dirname,'..', '..', 'public', 'about.html'));
  });

router.get('/menu', (req, res) => {
    //res.send('Hello, World! I am currently making a web app !');
    res.sendFile(path.join(__dirname,'..', '..', 'public', 'menu.html'));
  });

router.get('/events', (req, res) => {
    //res.send('Hello, World! I am currently making a web app !');
    res.sendFile(path.join(__dirname,'..','..', 'public', 'events.html'));
  });
  
router.get('/gallery', (req, res) => {
    //res.send('Hello, World! I am currently making a web app !');
    res.sendFile(path.join(__dirname,'..','..', 'public', 'gallery.html'));
  });
  
router.get('/chefs', (req, res) => {
    //res.send('Hello, World! I am currently making a web app !');
    res.sendFile(path.join(__dirname,'..','..', 'public', 'chefs.html'));
  });
  
router.get('/contact', (req, res) => {
    //res.send('Hello, World! I am currently making a web app !');
    res.sendFile(path.join(__dirname,'..','..', 'public', 'contact.html'));
  });


router.post('/auth/register', async (req, res) =>{
    //create a new user
    const { username, password } = req.body;

    try {
        // Check if the username already exists
        const existingUser = await User.findOne({ username });
        if (existingUser) {
          console.log('Submitted form data:', req.body);
          console.log('User already exists !');
          return res.status(400).json({ error: 'Username already exists' });
        }

         // Hash the password using bcryptjs
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);
    
        // Create a new user
        const newUser = new User({ username, password: hashedPassword });
        await newUser.save();

        console.log('Submitted form data:', req.body);
        console.log('User registered successfully');
        res.status(201).json({ message: 'User registered successfully' });
        //res.redirect('/?userCreatedSuccess=true');
        
      } catch (error) {
        // Handle any errors
        console.error(error);
        res.status(500).json({ error: 'An error occurred while registering the user' });
      }
});

router.post('/auth/login', async (req, res) =>{
  //login a user
  const { username_l, password_l } = req.body;

  try {
    // Check if the user exists
    const user = await User.findOne({ username: username_l });

    if (!user) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    console.log('user found!');

    // Compare the provided password with the hashed password in the database
    const isPasswordValid = await bcrypt.compare(password_l, user.password);

    if (!isPasswordValid) {
      console.log("invalid password !");
      return res.status(401).json({ error: 'Invalid username or password' });
      
    }

    console.log('and also, paswword is correct !');

    // Generate a JWT token
    console.log('JWT_SECRET:', process.env.JWT_SECRET);
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    console.log('Login successful!');
    console.log('Received token:', token);

     // Check the user's role
    res.json({ token, username: user.username, role: user.role });

    // Store the token in a secure way (e.g., in a session or as a cookie)
    // For simplicity, we'll just send the token back to the client
   

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred while logging in' });
  }

});



router.post('/auth/login/admin', async (req, res) =>{
  //login a user
  const { username_la, password_la } = req.body;

  try {
    // Check if the user exists
    const user = await User.findOne({ username: username_la });

    if (!user) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    console.log('user found!');

    // Compare the provided password with the hashed password in the database
    const isPasswordValid = await bcrypt.compare(password_la, user.password);

    if (!isPasswordValid) {
      console.log("invalid password !");
      return res.status(401).json({ error: 'Invalid username or password' });
      
    }

    console.log('and also, password is correct !');

    if (user.role === 'user') {
      return res.status(403).json({ error: 'Access denied. Only admin users can log in.' });
    }

    // Generate a JWT token
    console.log('JWT_SECRET:', process.env.JWT_SECRET);
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    console.log('Login successful!');
    console.log('Received token:', token);

     // Check the user's role
    res.json({ token, username: user.username, role: user.role });

    // Store the token in a secure way (e.g., in a session or as a cookie)
    // For simplicity, we'll just send the token back to the client
   

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred while logging in' });
  }

});




router.post('/submitReservation', (req, res) => {

    const { name, surname, date, hour } = req.body;
  
    // Create a new reservation document
    const newReservation = new Reservation({
      name,
      surname,
      date,
      hour
    });
  
    // Save the reservation to the database
    newReservation.save()
      .then(() => {
        console.log('Submitted form data:', req.body);
        console.log('Reservation saved successfully');
        //res.sendStatus(200); // Set the response status code to 200
        res.redirect('/?reservationSuccess=true');
        
      })
      .catch((error) => {
        res.status(500).send('Error saving reservation');
      });
  });
  

router.post('/reviews/addReview', async (req, res) => {
    try {
      const { username, chefID, rating, comment } = req.body;
  
      // Create a new review document
      const newReview = new chefReview({
        username,
        chefID,
        rating,
        comment,
      });
  
      console.log('review kaydedilmek uzere');
      // Save the review to the database
      await newReview.save();

      console.log('review kaydedildi');
  
      // Return a success response
      res.status(201).json({ message: 'Review submitted successfully' });
    } catch (error) {
      // Handle any errors that occur during the review submission
      console.error('Error saving review:', error);
      res.status(500).json({ error: 'Error saving review' });
    }
  });


  router.get('/reviews/:chefId', async (req, res) => {
    try {
      const chefId = req.params.chefId;
      console.log(chefId);
      const reviews = await chefReview.find({ chefID: chefId });
      console.log('reviews found !');

      if (reviews.length === 0) {
        // If there are no reviews for the given chefId
        res.status(404).json({ message: `No reviews found for chef with ID ${chefId}` });
      }
      else{
      res.json(reviews);
      }
      
    } catch (error) {
      console.error('Error retrieving reviews:', error);
      res.status(500).json({ error: 'Error retrieving reviews' });
    }
  });
  

  router.delete('/reviews/:id', async (req, res) => {
    try {
      console.log('the delete request was made!');
      const reviewId = req.params.id;
      const result = await chefReview.deleteOne({ _id: reviewId });
  
      if (result.deletedCount === 0) {
        return res.status(404).json({ error: 'Review not found' });
      }
  
      res.json({ message: 'Review deleted successfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'An error occurred while deleting the review' });
    }
  });
  
  

router.get('/admin-dashboard', async (req, res) => {
  try {
      res.sendFile(path.join(__dirname, '..', '..', 'public', 'admin_dashboard.html'));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred while checking user role' });
  }
});





router.post('/users', (req, res) =>{
    //create a new user
    res.send('User created succesfully');
});





module.exports = router;