const mongoose = require('mongoose');

const reservationSchema = new mongoose.Schema({
    name: String,
    surname: String,
    date: Date,
    hour: Number
  },{
   collection: 'reservations'
  });

const Reservation = mongoose.model('Reservation', reservationSchema);



module.exports = Reservation;


