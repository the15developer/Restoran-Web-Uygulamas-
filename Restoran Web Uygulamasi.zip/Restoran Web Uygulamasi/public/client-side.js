
const form_register = document.getElementById('registration-form');

form_register.addEventListener('submit', async (event) => {
  
  event.preventDefault();
  console.log("R form Submitted");

  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  console.log(username);
  console.log(password);

  try {
    const response = await fetch('/auth/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password}),
    });

    console.log('the request was made');

    const data = await response.json();

    if (response.ok) {
      // Handle successful registration
      console.log('the request was made and it received an OK response - which means that the user was registered succesfully');
      console.log(data.message);

      const successMessage = document.createElement('div');
      successMessage.textContent = 'Hesabiniz olusturulmustur!';
      successMessage.classList.add('success-message');
      const closeButton = document.createElement('button');

      closeButton.textContent = 'Close';
      closeButton.addEventListener('click', () => {
      successMessage.remove();
      form_register.reset();
  });

      successMessage.appendChild(closeButton);
      
      document.body.appendChild(successMessage);

    } else if(response.status === 400){

      const errorMessage = document.createElement('div');
      errorMessage.textContent = 'Kullanici adi zaten mevcuttur!';
      errorMessage.classList.add('error-message');
      const closeButton = document.createElement('button');

      closeButton.textContent = 'Close';
      closeButton.addEventListener('click', () => {
      errorMessage.remove();
      form_register.reset();
  });

      errorMessage.appendChild(closeButton);
      
      document.body.appendChild(errorMessage);

      // Handle registration error
      console.log('Error : either the user already exists, or there was an other error during registartion');
      console.error(data.error);
      // Display an error message to the user
    }

  } catch (error) {
    console.error('Error: the post request for the user registration form could not be made', error);
    // Handle any network or other errors
  }
});


const form_login=document.getElementById('login-form');

form_login.addEventListener('submit', async (event) => {
  
  event.preventDefault();
  console.log("L form Submitted");

  const username_l = document.getElementById('username_l').value;
  const password_l = document.getElementById('password_l').value;


  try {
    const response = await fetch('/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username_l, password_l}),
    });

    const data = await response.json();

    if (response.ok) {

      console.log('Login successful!');

      
      console.log('Received token:', data.token);

      // Store the token securely (e.g., in localStorage, a cookie, or a secure session)
      localStorage.setItem('authToken', data.token);

  // Store the user's username in localStorage
      localStorage.setItem('username', data.username);
      localStorage.setItem('userRole', data.role);

      const successMessage = document.createElement('div');
      successMessage.textContent = `Hos geldiniz, ${data.username}`;
      successMessage.classList.add('success-message');
      const closeButton = document.createElement('button');

      closeButton.textContent = 'Close';

      closeButton.addEventListener('click', () => {
      successMessage.remove();
      form_login.reset();

  });
      successMessage.appendChild(closeButton);
      
      document.body.appendChild(successMessage);

      const loginButton = document.getElementById('authLink');
      const loginButton2 = document.getElementById('authAdmin');

      loginButton.textContent=`Logout, ${data.username}`;
     
      loginButton.addEventListener('click', () => {

        handleLogout();
});
      loginButton2.style.display='none';
     
      
    } else{

      console.error('Login failed:', data.error);

      // Display an error message to the user
      const errorMessage = document.createElement('div');
      errorMessage.textContent = 'Sifre/username hatali !';
      errorMessage.classList.add('error-message');

      const closeButton = document.createElement('button');
      closeButton.textContent = 'Close';
      closeButton.addEventListener('click', () => {
      errorMessage.remove();
      form_login.reset();
  });
      errorMessage.appendChild(closeButton);
      
      document.body.appendChild(errorMessage);

      // Handle registration error
      console.log('Error : login failed');
      console.error(data.error);
      // Display an error message to the user
    }

  } catch (error) {
    console.error('Error:', error);
    // Handle any network or other errors
  }
});


const form_login_admin=document.getElementById('login-form-admin');

form_login_admin.addEventListener('submit', async (event) => {
  
  event.preventDefault();
  console.log("LA form Submitted");

  const username_la = document.getElementById('username_la').value;
  const password_la = document.getElementById('password_la').value;

  if(localStorage.getItem('username')){
    handleLogout();
  }


  try {
    const response = await fetch('/auth/login/admin', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username_la, password_la}),
    });

    const data = await response.json();

    if (response.ok) {

      console.log('Login successful!');
      console.log('Received token:', data.token);

      // Store the token securely (e.g., in localStorage, a cookie, or a secure session)
      localStorage.setItem('authToken', data.token);
      localStorage.setItem('username', data.username);
      localStorage.setItem('userRole', data.role);

      const loginButton = document.getElementById('authLink');
      const loginButton2=document.getElementById('authAdmin');

      loginButton.textContent=`Logout, ${data.username}`;
     
      loginButton.addEventListener('click', () => {

        handleLogout();
        loginButton2.textContent='login as admin';
        loginButton2.addEventListener('click', openLogin2);

        
});

      
      loginButton2.textContent='admin modu';
      loginButton2.addEventListener('click', () => {
        
        window.location.href = '/admin-dashboard';
});

       window.location.href = '/admin-dashboard';

     
      
    } 

    else if (response.status === 403) {
      // Create a new error message element
      const errorMessage = document.createElement('div');
      errorMessage.textContent = 'Access denied. Only admin users can log in.';
      errorMessage.classList.add('error-message');

      // Add a close button to the error message
      const closeButton = document.createElement('button');
      closeButton.textContent = 'Close';
      closeButton.addEventListener('click', () => {
        errorMessage.remove();
        form_login_admin.reset();
      });
      errorMessage.appendChild(closeButton);

      // Add the error message to the DOM
      document.body.appendChild(errorMessage);
    }
    
    
    
    else{

      console.error('Login failed:', data.error);

      // Display an error message to the user
      const errorMessage = document.createElement('div');
      errorMessage.textContent = 'Sifre/username hatali !';
      errorMessage.classList.add('error-message');

      const closeButton = document.createElement('button');
      closeButton.textContent = 'Close';
      closeButton.addEventListener('click', () => {
      errorMessage.remove();
      form_login.reset();
  });
      errorMessage.appendChild(closeButton);
      
      document.body.appendChild(errorMessage);

      // Handle registration error
      console.log('Error : login failed');
      console.error(data.error);
      // Display an error message to the user
    }

  } catch (error) {
    console.error('Error:', error);
    // Handle any network or other errors
  }
});




function handleLogout() {
  // Remove the token and username from localStorage
  localStorage.removeItem('authToken');
  localStorage.removeItem('username');
  localStorage.removeItem('userRole');


  // Update the login/logout button
  const loginButton = document.getElementById('authLink');
  loginButton.textContent = `login`;
  loginButton.addEventListener('click', openLogin);
  
}



function openLogin() {
  var dialog = document.getElementById('login');
  dialog.style.display="block";
}




function handleLogin(){
  
  const authToken = localStorage.getItem('authToken');
  const username = localStorage.getItem('username');
// Remove the token and username from localStorage

 if (authToken && username) {
// User is authenticated, update the button to "Logout, [username]"
const errorM=document.createElement('div');
errorM.textContent='Once cikis yapin !';
errorM.classList.add('error-message');

const closeButton = document.createElement('button');
closeButton.textContent = 'Close';

closeButton.addEventListener('click', () => {
errorM.remove();
});

errorM.appendChild(closeButton);
document.body.appendChild(errorM);
}
else{
openLogin();
}

}




